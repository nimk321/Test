package com.cestar.view;

import java.util.Scanner;

import com.cestar.controller.controller;

public class usermenu {

    public static void main(String[] args) {
        
        controller controller = new controller();
        Scanner sc = new Scanner(System.in);
        int entry = 0;
        
        // Infinite loop until the user chooses to exit
        while (entry != 6) {
            System.out.println("***********************************************");
            System.out.println("* Please Select One of the following Options  *");
            System.out.println("***********************************************");
            System.out.println("******* Enter 1 to display all records ********");
            System.out.println("******* Enter 2 to Insert New Record   ********");
            System.out.println("******* Enter 3 to Fetch Record By Id  ********");
            System.out.println("******* Enter 4 to Update Record By Id ********");
            System.out.println("******* Enter 5 to Delete Record By Id ********");
            System.out.println("*******  Enter 6 to Exit Application   ********");
            System.out.println("***********************************************");
            
            entry = sc.nextInt();
            
            switch (entry) {
                case 1: {
                    controller.display();
                    break;
                }
                case 2: {
                    controller.insert();
                    break;
                }
                case 3: {
                    controller.findRecById();
                    break;
                }
                case 4: {
                    controller.updateById();
                    break;
                }
                case 5: {
                    controller.delById();
                    break;
                }
                case 6: {
                    System.out.println("Thanks for Using Our Application. Goodbye!");
                    System.exit(0);
                    break;
                }
                default: {
                    System.out.println("Please Enter a number from 1 to 6 Only !!!");
                    break;
                }
            }
        }
    }
}
