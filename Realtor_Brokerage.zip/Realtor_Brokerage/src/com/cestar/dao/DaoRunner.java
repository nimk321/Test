package com.cestar.dao;

import com.cestar.model.Property;

public class DaoRunner {

    public static void main(String[] args) {
        
        PropertyDao dao = new PropertyDao();
        
        // Read all properties
        dao.read();
                
        // Create a new property
//        Property propertyToAdd = new Property(9, "New Name", 250000.00, "Suburban", "Single Family", "2024-01-15");
//        dao.create(propertyToAdd);
        
        // Retrieve property by ID
//       dao.getRecById(1);
        
        // Delete property by ID
//        dao.deleteById(1);
        
        // Update property by ID
//        int id = 1;
//      Property updatedProperty = new Property(1, "New Agent", 300000.00, "New Region", "New Type", "2023-01-01");
//       dao.updateById(id, updatedProperty);
    }
}
