package com.cestar.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cestar.model.Property;

public class PropertyDao {

    // Method to establish connection with the database
    public Connection setupConnection() {
        Connection con = null;

        String url = "jdbc:mysql://localhost:3306/Brokerage";
        String user = "root";
        String pwd = "1234";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, user, pwd);
            System.out.println("Connection Successful !!!");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return con;
    }

    // Method to retrieve all properties from the database
    public List<Property> read() {
        List<Property> properties = new ArrayList<>();
        Connection con = setupConnection();
        String sql = "SELECT * FROM Properties";

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Property property = new Property(
                        rs.getInt("PropertyId"),
                        rs.getString("AgentName"),
                        rs.getDouble("AskingPrice"),
                        rs.getString("Region"),
                        rs.getString("Type"),
                        rs.getString("ClosingDate")
                );
                properties.add(property);
            }

            System.out.println(properties);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return properties;
    }

    // Method to create a new property record in the database
    public void create(Property property) {
        Connection con = setupConnection();
        String sql = "INSERT INTO Properties (AgentName, AskingPrice, Region, Type, ClosingDate) VALUES (?, ?, ?, ?, ?)";

        try {
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, property.getAgentName());
            pstmt.setDouble(2, property.getAskingPrice());
            pstmt.setString(3, property.getRegion());
            pstmt.setString(4, property.getType());
            pstmt.setString(5, property.getClosingDate());

            int status = pstmt.executeUpdate();

            if (status > 0) {
                System.out.println("Record Inserted Successfully !!!");
                read();
            } else {
                System.out.println("Please Try Again !!!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to retrieve a property record by its ID
    public Property getRecById(int id) {
        Connection con = setupConnection();
        String sql = "SELECT * FROM Properties WHERE PropertyId = ?";
        Property property = null;

        try {
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                property = new Property(
                        rs.getInt("PropertyId"),
                        rs.getString("AgentName"),
                        rs.getDouble("AskingPrice"),
                        rs.getString("Region"),
                        rs.getString("Type"),
                        rs.getString("ClosingDate")
                );
            }

            System.out.println(property);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return property;
    }

    // Method to delete a property record by its ID
    public void deleteById(int id) {
        Connection con = setupConnection();
        String sql = "DELETE FROM Properties WHERE PropertyId = ?";

        try {
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, id);

            int status = pstmt.executeUpdate();

            if (status > 0) {
                System.out.println("Record Deleted Successfully !!!");
                read();
            } else {
                System.out.println("Please Try Again !!!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to update a property record by its ID
    public void updateById(int id, Property updatedProperty) {
        Connection con = setupConnection();
        String sql = "UPDATE Properties SET AgentName=?, AskingPrice=?, Region=?, Type=?, ClosingDate=? WHERE PropertyId=?";

        try {
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, updatedProperty.getAgentName());
            pstmt.setDouble(2, updatedProperty.getAskingPrice());
            pstmt.setString(3, updatedProperty.getRegion());
            pstmt.setString(4, updatedProperty.getType());
            pstmt.setString(5, updatedProperty.getClosingDate());
            pstmt.setInt(6, id);

            int status = pstmt.executeUpdate();

            if (status > 0) {
                System.out.println("Record Updated Successfully !!!");
                read();
            } else {
                System.out.println("Query Failed !!! Try Again Please !!!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
