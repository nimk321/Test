package com.cestar.controller;

import java.util.Scanner;

import com.cestar.dao.PropertyDao;
import com.cestar.model.Property;

public class controller {
    
    PropertyDao dao = new PropertyDao(); // Creating an instance of PropertyDao
    Scanner sc = new Scanner(System.in); // Scanner object for user input
    
    // Method to display all property records
    public void display() {
        System.out.println("**** Welcome To Display Records Option in our Application ****");
        dao.read(); // Call the read method from PropertyDao to display records
    }
    
    // Method to insert a new property record
    public void insert() {
        System.out.println("**** Welcome To Insert Records Option in our Application ****");
        
        // Gathering input from the user for property details
        System.out.print("Please Enter the Agent Name: ");
        String agentName = sc.nextLine();
        
        System.out.print("Please Enter the Asking Price: ");
        double askingPrice = sc.nextDouble();
        sc.nextLine(); // Consume newline
        
        System.out.print("Please Enter the Region: ");
        String region = sc.nextLine();
        
        System.out.print("Please Enter the Type: ");
        String type = sc.nextLine();
        
        System.out.print("Please Enter the Closing Date (YYYY-MM-DD): ");
        String closingDate = sc.nextLine();
        
        // Creating a Property object with the gathered details
        Property property = new Property(0, agentName, askingPrice, region, type, closingDate);
        
        // Call the create method from PropertyDao to insert the property record
        dao.create(property);
    }
    
    // Method to find a property record by ID
    public void findRecById() {
        System.out.println("**** Welcome To Find Record By Id Option in our Application ****");
        
        // Gathering input from the user for the property ID
        System.out.print("Please Enter the Property ID: ");
        int propertyId = sc.nextInt();
        
        // Call the getRecById method from PropertyDao to retrieve the property record by ID
        dao.getRecById(propertyId);
    }
    
    // Method to delete a property record by ID
    public void delById() {
        System.out.println("**** Welcome To Delete Record By Id Option in our Application ****");
        
        // Gathering input from the user for the property ID
        System.out.print("Please Enter the Property ID: ");
        int propertyId = sc.nextInt();
        
        // Call the deleteById method from PropertyDao to delete the property record by ID
        dao.deleteById(propertyId);
    }
    
    // Method to update a property record by ID
    public void updateById() {
        System.out.println("**** Welcome To Update Record By Id Option in our Application ****");
        
        // Gathering input from the user for the property ID to be updated
        System.out.print("Please Enter the Property ID to update: ");
        int propertyIdToUpdate = sc.nextInt();
        sc.nextLine(); // Consume newline
        
        // Gathering input from the user for the new property details
        System.out.print("Please Enter the New Agent Name: ");
        String agentName = sc.nextLine();
        
        System.out.print("Please Enter the New Asking Price: ");
        double askingPrice = sc.nextDouble();
        sc.nextLine(); // Consume newline
        
        System.out.print("Please Enter the New Region: ");
        String region = sc.nextLine();
        
        System.out.print("Please Enter the New Type: ");
        String type = sc.nextLine();
        
        System.out.print("Please Enter the New Closing Date (YYYY-MM-DD): ");
        String closingDate = sc.nextLine();
        
        // Creating a Property object with the new details
        Property updatedProperty = new Property(propertyIdToUpdate, agentName, askingPrice, region, type, closingDate);
        
        // Call the updateById method from PropertyDao to update the property record by ID
        dao.updateById(propertyIdToUpdate, updatedProperty);
    }
}
