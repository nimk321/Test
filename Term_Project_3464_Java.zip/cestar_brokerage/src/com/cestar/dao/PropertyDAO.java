package com.cestar.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.cestar.model.Property;

	public class PropertyDAO {
	    private Connection connection;

	    // Constructor
	    public PropertyDAO() {
	        // Initialize database connection
	        try {
	            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cestardb", "root", "1234");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    // Method to retrieve all properties from the database
	    public List<Property> getAllProperties() {
	        List<Property> properties = new ArrayList<>();
	        String query = "SELECT * FROM Properties";
	        try (PreparedStatement statement = connection.prepareStatement(query);
	             ResultSet resultSet = statement.executeQuery()) {
	            while (resultSet.next()) {
	                Property property = new Property(
	                        resultSet.getInt("PropertyId"),
	                        resultSet.getString("AgentName"),
	                        resultSet.getDouble("AskingPrice"),
	                        resultSet.getString("Region"),
	                        resultSet.getString("Type"),
	                        resultSet.getString("ClosingDate")
	                );
	                properties.add(property);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return properties;
	    }

      // Insert Method
	    public boolean insertProperty(Property property) {
	        String query = "INSERT INTO Properties (AgentName, AskingPrice, Region, Type, ClosingDate) VALUES (?, ?, ?, ?, ?)";
	        try (PreparedStatement statement = connection.prepareStatement(query)) {
	            statement.setString(1, property.getAgentName());
	            statement.setDouble(2, property.getAskingPrice());
	            statement.setString(3, property.getRegion());
	            statement.setString(4, property.getType());
	            statement.setString(5, property.getClosingDate());
	            int rowsInserted = statement.executeUpdate();
	            return rowsInserted > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }
     // Update method
	    public boolean updateProperty(Property property) {
	        String query = "UPDATE Properties SET AgentName=?, AskingPrice=?, Region=?, Type=?, ClosingDate=? WHERE PropertyId=?";
	        try (PreparedStatement statement = connection.prepareStatement(query)) {
	            statement.setString(1, property.getAgentName());
	            statement.setDouble(2, property.getAskingPrice());
	            statement.setString(3, property.getRegion());
	            statement.setString(4, property.getType());
	            statement.setString(5, property.getClosingDate());
	            statement.setInt(6, property.getPropertyId());
	            int rowsUpdated = statement.executeUpdate();
	            return rowsUpdated > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }
    // Delete Method
	    public boolean deleteProperty(int propertyId) {
	        String query = "DELETE FROM Properties WHERE PropertyId=?";
	        try (PreparedStatement statement = connection.prepareStatement(query)) {
	            statement.setInt(1, propertyId);
	            int rowsDeleted = statement.executeUpdate();
	            return rowsDeleted > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }

	}


