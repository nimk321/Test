package com.cestar.dao;


import java.util.List;

import com.cestar.model.Property;

	public class DaoRunner {
	    public static void main(String[] args) {
	        PropertyDAO propertyDAO = new PropertyDAO();

	        // Display data using JavaFX or console
	        List<Property> properties = propertyDAO.getAllProperties();
	        for (Property property : properties) {
	            System.out.println(property);
	        }
	        // Insert a new property
	        Property newProperty = new Property(0, "Hamro Dai", 275000.00, "Suburban", "Single Family", "2023-05-30");
	        boolean inserted = propertyDAO.insertProperty(newProperty);
	        System.out.println("Property inserted: " + inserted);

	        // Update an existing property
	        Property existingProperty = propertyDAO.getAllProperties().get(1); 
	        existingProperty.setAskingPrice(300000.00);
	        boolean updated = propertyDAO.updateProperty(existingProperty);
	        System.out.println("Property updated: " + updated);

	        // Delete a property
	        int propertyIdToDelete = 2;
	        boolean deleted = propertyDAO.deleteProperty(propertyIdToDelete);
	        System.out.println("Property deleted: " + deleted);
	    }
	}



