package com.cestar.model;

public class Property {

	    private int propertyId;
	    private String agentName;
	    private double askingPrice;
	    private String region;
	    private String type;
	    private String closingDate;

	    // Constructor
	    public Property(int propertyId, String agentName, double askingPrice, String region, String type, String closingDate) {
	        this.propertyId = propertyId;
	        this.agentName = agentName;
	        this.askingPrice = askingPrice;
	        this.region = region;
	        this.type = type;
	        this.closingDate = closingDate;
	    }

	    // Getters and setters
	    public int getPropertyId() {
	        return propertyId;
	    }

	    public void setPropertyId(int propertyId) {
	        this.propertyId = propertyId;
	    }

	    public String getAgentName() {
	        return agentName;
	    }

	    public void setAgentName(String agentName) {
	        this.agentName = agentName;
	    }

	    public double getAskingPrice() {
	        return askingPrice;
	    }

	    public void setAskingPrice(double askingPrice) {
	        this.askingPrice = askingPrice;
	    }

	    public String getRegion() {
	        return region;
	    }

	    public void setRegion(String region) {
	        this.region = region;
	    }

	    public String getType() {
	        return type;
	    }

	    public void setType(String type) {
	        this.type = type;
	    }

	    public String getClosingDate() {
	        return closingDate;
	    }

	    public void setClosingDate(String closingDate) {
	        this.closingDate = closingDate;
	    }

	    // toString method for printing property details
	    @Override
	    public String toString() {
	        return "Property{" +
	                "propertyId=" + propertyId +
	                ", agentName='" + agentName + '\'' +
	                ", askingPrice=" + askingPrice +
	                ", region='" + region + '\'' +
	                ", type='" + type + '\'' +
	                ", closingDate='" + closingDate + '\'' +
	                '}';
	    }
	}


